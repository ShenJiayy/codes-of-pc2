#include <bits/stdc++.h>
using namespace std;
int n,m;
int main()
{
	freopen("e.in","r",stdin);
	freopen("e.out","w",stdout);
	cin >> n >> m;
	for(int i=1; i<=n; i++)
	{
		cout << 0 << endl;
	}
	return 0;
 } 
